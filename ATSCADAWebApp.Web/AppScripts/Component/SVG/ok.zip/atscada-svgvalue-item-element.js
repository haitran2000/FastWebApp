﻿
export class AtscadaSVGValueItemElement extends HTMLElement {
    constructor() {
        super();

        this.content = 'SVGValue Item';
        this.color = '#00acac';
        this.dataTagName = 'TaskName.TagName';
    }

    connectedCallback() {
        this.content = this.getAttribute('at-content') || this.content;
        this.color = this.getAttribute('at-color') || this.color;
        this.dataTagName = this.getAttribute('at-data-tag-name') || this.dataTagName;
    }   
}

customElements.define('atscada-svgvalue-item', AtscadaSVGValueItemElement);