﻿import { AtscadaDispatcher } from '../../Core/Common/atscada-dispatcher.js'

export class AtscadaSVGView {
    constructor(model, element) {
        this.model = model;
        this.element = element;
        this.dispatcher = new AtscadaDispatcher();
        this.title = element.content;
        this.arrowIn = element.arrowIn;
        this.arrowOut = element.arrowOut;

        this.logo = element.logo;
        this.date = element.date;
        this.time = element.time;
        this.titleUp = element.titleUp;
        this.titleDown = element.titleDown;

        this.count = true;   
        this.show = [false, false, false];
        this.check = [false, false, false, false, false];       
    }

    initialize() {
    tagStatus(status) {
        if (status === 'Good') {

        }
        else {

        }
    }
    // Simulate 2 arrow in, out
    simulateArrow() {
        if (this.count) {
            this.arrowIn.style.display = "none";
            this.arrowOut.style.display = "none";
        }
        else {
            this.arrowIn.style.display = "inline";
            this.arrowOut.style.display = "inline";
        }

        this.count = !this.count;
    }

    simulateAlarm(parameter, id) {
        var alarmCss = parameter.style.cssText;
        if (this.check[id]) {
            var newCss = alarmCss.replaceAll("rgb(255, 255, 255)", "rgb(255, 0, 0)");
            parameter.style.cssText = newCss;
        }
        else {
            var newCss = alarmCss.replaceAll("rgb(255, 0, 0)", "rgb(255, 255, 255)");
            parameter.style.cssText = newCss;
        }

        this.check[id] = !this.check[id];
    }
    redirectLink(url) {
        if (url == '' || url === 'http://') return;
        if (url.includes('http')) {
            window.open(url, '_blank');
        }
        else if (url.includes('~/')) {
            window.location.hash = `/${url.split('/')[1]}`;
        }
    }

    now() {
        var date = new Date();
        let day = ("0" + date.getDate()).slice(-2);
        let month = ("0" + (date.getMonth() + 1)).slice(-2);
        let year = date.getFullYear();
        let hour = ("0" + date.getHours()).slice(-2);
        let minute = ("0" + date.getMinutes()).slice(-2);
        let second = ("0" + date.getSeconds()).slice(-2);
        let currentDate = `${day}/${month}/${year}`;
        let currentTime = `${hour}:${minute}:${second}`;
        this.date.innerHTML = currentDate;
        this.time.innerHTML = currentTime;
    }

    dispose() { }
}