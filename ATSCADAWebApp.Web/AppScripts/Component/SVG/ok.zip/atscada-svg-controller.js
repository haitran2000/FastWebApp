﻿
export class AtscadaSVGController {
    constructor(view) {
        this.view = view;
        this.timeoutWrite = undefined;
    }

    initialize() {

    }

    dispose() { }
}
